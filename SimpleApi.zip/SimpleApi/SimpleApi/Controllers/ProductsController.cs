using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using SimpleApi;

namespace SimpleApi.Controllers;

// [Route] определяет URL, по которому будет доступен контроллер
// "api/[controller]" — [controller] заменяется на имя контроллера без суффикса
// Получается: "api/products"
[Route("api/[controller]")]

// [ApiController] включает ряд полезных функций:
// - Автоматическая проверка ModelState (если есть ошибки валидации → 400 Bad Request)
// - Автоматическая привязка [FromBody] для сложных объектов
// - Подробные ошибки валидации
[ApiController]
public class ProductsController : ControllerBase
{
    // Контекст базы данных, внедряется через Dependency Injection
    // ASP.NET Core автоматически создаст и передаст экземпляр
    private readonly AppDbContext _context;

    // Конструктор — вызывается при каждом запросе
    // _context будет содержать подключение к БД
    public ProductsController(AppDbContext context)
    {
        _context = context;
    }

    // ========== GET: api/products ==========
    // Получение списка всех товаров
    // HTTP GET — идемпотентный метод (не изменяет данные)

    [HttpGet]  // Атрибут указывает, что метод отвечает на GET запросы
    public async Task<ActionResult<IEnumerable<ProductDto>>> GetProducts()
    {
        // _context.Products — это DbSet<Product>
        // .Select() — преобразуем каждый Product в ProductDto
        // .ToListAsync() — выполняем SQL запрос и получаем список
        // Async — не блокируем поток, пока идет запрос к БД

        var products = await _context.Products
            .Select(p => new ProductDto
            {
                Id = p.Id,
                Name = p.Name,
                Price = p.Price,
                Stock = p.Stock
            })
            .ToListAsync();  // Здесь происходит реальный запрос к БД

        // Ok() возвращает HTTP 200 OK с телом ответа
        return Ok(products);
    }

    // ========== GET: api/products/{id} ==========
    // Получение одного товара по ID

    [HttpGet("{id}")]  // {id} — параметр маршрута, будет подставлен в URL
    public async Task<ActionResult<ProductDto>> GetProduct(int id)
    {
        // FindAsync — ищет запись по первичному ключу
        // Это самый быстрый способ получить запись по Id
        var product = await _context.Products.FindAsync(id);

        // Если товар не найден, возвращаем 404 Not Found
        // new { message = ... } — анонимный объект с сообщением об ошибке
        if (product == null)
        {
            return NotFound(new { message = $"Product with id {id} not found" });
        }

        // Преобразуем найденную модель в DTO
        var productDto = new ProductDto
        {
            Id = product.Id,
            Name = product.Name,
            Price = product.Price,
            Stock = product.Stock
        };

        // Возвращаем 200 OK с товаром
        return Ok(productDto);
    }

    // ========== POST: api/products ==========
    // Создание нового товара
    // HTTP POST — не идемпотентный (каждый запрос создает новый ресурс)

    [HttpPost]
    // [FromBody] — говорит, что данные нужно взять из тела запроса
    // ASP.NET автоматически распарсит JSON в объект CreateProductDto
    public async Task<ActionResult<ProductDto>> CreateProduct([FromBody] CreateProductDto createDto)
    {
        // ===== ВАЛИДАЦИЯ =====
        // Всегда проверяйте входные данные!
        // Никогда не доверяйте данным от клиента

        // Проверка имени: не пустое и не состоит из пробелов
        if (string.IsNullOrWhiteSpace(createDto.Name))
        {
            // BadRequest = 400 Bad Request
            return BadRequest(new { message = "Name is required" });
        }

        // Проверка цены: должна быть положительной
        if (createDto.Price <= 0)
        {
            return BadRequest(new { message = "Price must be greater than 0" });
        }
        // Проверка количества: не может быть отрицательным
        if (createDto.Stock < 0)
        {
            return BadRequest(new { message = "Stock cannot be negative" });
        }

        // ===== СОЗДАНИЕ =====
        // Создаем новую модель Product из DTO
        var product = new Product
        {
            Name = createDto.Name,
            Price = createDto.Price,
            Stock = createDto.Stock
        };

        // Добавляем в контекст (помечаем как "новый")
        _context.Products.Add(product);

        // Сохраняем изменения в базе данных
        // SaveChangesAsync генерирует INSERT SQL запрос
        // База данных автоматически присвоит Id
        await _context.SaveChangesAsync();

        // ===== ФОРМИРОВАНИЕ ОТВЕТА =====
        var result = new ProductDto
        {
            Id = product.Id,     // Id теперь есть, его присвоила БД
            Name = product.Name,
            Price = product.Price,
            Stock = product.Stock
        };

        // CreatedAtAction возвращает HTTP 201 Created
        // Параметры:
        // 1. nameof(GetProduct) — имя метода, который может получить созданный ресурс
        // 2. new { id = product.Id } — параметры для вызова GetProduct
        // 3. result — тело ответа
        // В заголовке Location будет: /api/products/5
        return CreatedAtAction(nameof(GetProduct), new { id = product.Id }, result);
    }

    // ========== PUT: api/products/{id} ==========
    // Полное обновление товара
    // HTTP PUT — идемпотентный (повторные запросы дают тот же результат)

    [HttpPut("{id}")]
    public async Task<ActionResult<ProductDto>> UpdateProduct(int id, [FromBody] UpdateProductDto updateDto)
    {
        // ===== ВАЛИДАЦИЯ =====
        if (string.IsNullOrWhiteSpace(updateDto.Name))
            return BadRequest(new { message = "Name is required" });

        if (updateDto.Price <= 0)
            return BadRequest(new { message = "Price must be greater than 0" });

        if (updateDto.Stock < 0)
            return BadRequest(new { message = "Stock cannot be negative" });

        // ===== ПОИСК СУЩЕСТВУЮЩЕГО ТОВАРА =====
        var product = await _context.Products.FindAsync(id);

        if (product == null)
        {
            return NotFound(new { message = $"Product with id {id} not found" });
        }

        // ===== ОБНОВЛЕНИЕ =====
        // Изменяем свойства существующего объекта
        // EF Core автоматически отслеживает изменения
        product.Name = updateDto.Name;
        product.Price = updateDto.Price;
        product.Stock = updateDto.Stock;

        // Сохраняем изменения
        // SaveChangesAsync сгенерирует UPDATE SQL запрос
        await _context.SaveChangesAsync();

        // ===== ОТВЕТ =====
        var result = new ProductDto
        {
            Id = product.Id,
            Name = product.Name,
            Price = product.Price,
            Stock = product.Stock
        };

        return Ok(result);  // HTTP 200 OK
    }

    // ========== DELETE: api/products/{id} ==========
    // Удаление товара

    [HttpDelete("{id}")]
    public async Task<ActionResult> DeleteProduct(int id)
    {
        // Находим товар
        var product = await _context.Products.FindAsync(id);

        if (product == null)
        {
            return NotFound(new { message = $"Product with id {id} not found" });
        }

        // Удаляем из контекста
        _context.Products.Remove(product);

        // Сохраняем изменения
        // SaveChangesAsync сгенерирует DELETE SQL запрос
        await _context.SaveChangesAsync();

        // NoContent = 204 No Content
        // Стандартный ответ для успешного DELETE (без тела ответа)
        return NoContent();
    }

    // ========== PATCH: api/products/{id}/stock ==========
    // Частичное обновление (только количество)
    // HTTP PATCH — для частичного обновления ресурса

    [HttpPatch("{id}/stock")]
    public async Task<ActionResult> UpdateStock(int id, [FromBody] int newStock)
    {
        var product = await _context.Products.FindAsync(id);

        if (product == null)
        {
            return NotFound(new { message = $"Product with id {id} not found" });
        }

        if (newStock < 0)
        {
            return BadRequest(new { message = "Stock cannot be negative" });
        }

        // Обновляем только Stock
        product.Stock = newStock;

        await _context.SaveChangesAsync();

        return Ok(new
        {
            id = product.Id,
            stock = product.Stock,
            message = "Stock updated successfully"
        });
    }
}
